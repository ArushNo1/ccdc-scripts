#!/bin/vbash
source /opt/vyatta/etc/functions/script-template

if [ "$(id -g -n)" != 'vyattacfg' ] ; then
    exec sg vyattacfg -c "/bin/vbash $(readlink -f $0) $@"
fi

set firewall global-options all-ping enable

set firewall ipv4 forward filter rule 10 action accept
set firewall ipv4 foward filter rule 10 inbound-interface ###WAN###
set firewall ipv4 forward fiter rule 10 destination address 172.20.240.10 
set firewall ipv4 forward filter rule 10 destination port 80,443,22,21,20,50000-50020

set firewall ipv4 forward filter rule 15 action accept
set firewall ipv4 foward filter rule 15 inbound-interface ###WAN###
set firewall ipv4 forward fiter rule 15 destination address 172.20.240.15
set firewall ipv4 forward filter rule 15 destination port 25,587,465,143,993,110,995,22

set firewall ipv4 forward filter rule 20 action accept
set firewall ipv4 foward filter rule 20 inbound-interface ###WAN###
set firewall ipv4 forward fiter rule 20 destination address 172.20.240.20
set firewall ipv4 forward filter rule 20 destination port 8089,22,8000

set firewall ipv4 forward filter rule 100 action accept
set firewall ipv4 foward filter rule 100 inbound-interface ###WAN###
set firewall ipv4 forward fiter rule 100 destination address 172.20.240.20
set firewall ipv4 forward filter rule 100 destination port 53,22,5985,5986

set firewall ipv4 forward filter rule 120 action accept
set firewall ipv4 foward filter rule 120 inbound-interface ###WAN###
set firewall ipv4 forward fiter rule 120 destination address 172.20.240.20
set firewall ipv4 forward filter rule 120 destination port 53,22,5985,5986