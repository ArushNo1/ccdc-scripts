# AGENTS.md

Read this file fully first before `SPEC.md`. This file is how to behave; `SPEC.md` is what to build. For this project, DO NOT access or edit another other files besides the ones in this directory and its subdirectories. Make minor design decision to conform with overall goal of project. Pause developement and ask for any major changes.

## Project
Two CLI scripts for a competition firewall admin: `scan_network.py` (nmap to YAML) and `build_firewall.py` (YAML + policy to pfSense/VyOS/nftables configs). Priorities: correctness, speed, readability.

## Scope
- Build only what `SPEC.md` lists. No tests, mocks, sample inputs, CI, Docker, packaging, linter config. No extra flags, keys or outputs; mention ideas in the final message instead.
- No backups, syntax validation, pushing, rollback, PAN-OS, or FTD (the registry must make later vendors easy to add).
- Do not modify `policy.yaml` or `templates/pfsense/*.xml`. 
- Stop and ask (question in the final message) when the spec is ambiguous, a required fixture is missing, or exact vendor syntax is uncertain. Never invent vendor syntax.

## Python
- Script 1, `scanner/`, `common/`: **Python 3.6**. Script 2, `builder/`: **3.13+**, nothing newer.
- Banned in 3.6 code: `dataclasses`, `from __future__ import annotations`, `subprocess.run(capture_output/text)` (use `stdout=PIPE, universal_newlines=True`), `fromisoformat`, walrus, positional-only params, `typing.Literal/Final/Protocol/TypedDict`, `removeprefix/removesuffix`, `list[str]`-style generics, `X | Y` unions, `match`. Use `typing.NamedTuple`, `List/Dict/Optional`.
- Dependencies (preinstalled, no wheels): scan side stdlib + PyYAML (`xml.etree` for nmap XML, no python-nmap); build side stdlib + PyYAML + Jinja2. Use `argparse` and `logging`. Nothing else. Files: `requirements-scan.txt`, `requirements-build.txt`.

## Style
- Pythonic and readable over short. No clever one-liners, nested comprehensions or metaprogramming beyond the vendor registry.
- Small single-purpose functions, descriptive names, type hints on signatures, short docstrings (module, class, public function), comments explain why.
- Prefer `pathlib`, f-strings, `ipaddress`, `collections`, `itertools`. Tunables in `SPEC.md` are named UPPER_SNAKE_CASE constants at module top.
- Entry scripts stay thin. No `eval`, `exec`, `shell=True`; pass nmap args as a list.
- Deterministic output (sorted groups, members, ports) apart from timestamps.
- Each stage is its own module with a narrow typed interface. A new vendor = one module in `builder/vendors/`, one `templates/` folder, one registry entry, nothing else. Shared modules never import vendor modules.

## Data safety
- Never delete or overwrite collected data: every run gets a new timestamped folder; if a path exists, add a numeric suffix.
- Preserve unknown YAML keys. Never modify an input file.

## Console
`logging`: INFO progress, WARNING for operator attention (prefix `WARNING:`), ERROR for fatal. Plain text, no emoji or colors. End each run with a summary repeating every WARNING.

## Final message
List: files created; deviations from `SPEC.md` and why; questions you stopped on; VERIFY items you could not confirm.
