# SPEC.md

Read `AGENTS.md` first (conventions, scope, Python rules). MUST = requirement. VERIFY = confirm against vendor docs or stop and ask. Both `scan_network.py` and `build_firewall.py` should be single Python files (keeping as closs to the style requirements in AGENTS.md).

## 1. Purpose and workflow
Operator is firewall admin in a competition: host IPs and services are known, ports are not.
```
inputs/assumed.yaml -> scan_network.py -> runs/<ts>/{actual,new,diff}.yaml, nmap/*.xml
runs/<ts>/new.yaml + inputs/firewall.yaml + policy.yaml -> build_firewall.py -> runs/<ts>/configs/<fw>/...
```
Script 1 runs as root on an internal machine (firewalls default-open). Script 2 runs on the operator's device. The operator applies configs by hand.

## 2. Scope
In: both scripts; pfSense, VyOS, nftables output; one Jinja2 template per construct; `README.md`, `requirements-scan.txt`, `requirements-build.txt`.
Out: PAN-OS, FTD, tests, backups, syntax checks, pushing, WAN rules, NAT, routes, IPv6 allow rules, traffic to the firewall itself.
Rules cover transit traffic between IP networks assigned to `lan` and `internal` roles. Match those networks by source and destination address, not by ingress or egress interface. A packet is in scope whenever its source and destination addresses belong to opposite LAN/internal network sets, regardless of the interfaces it traverses. Traffic outside those network pairs, including ordinary WAN traffic and same-role traffic, must pass through the generated policy unchanged.

## 3. Targets
pfSense CE 2.9.0 (config `<version>24.6</version>`); VyOS 1.5 (circinus); nftables 1.1.7; nmap on PATH. Script 1 MUST exit 1 with a clear message unless `os.geteuid() == 0` (and Windows equivalent). Pin PyYAML in `requirements-scan.txt` to a release that installs on 3.6 (6.0). `requirements-build.txt`: `PyYAML>=6.0.2`, `Jinja2>=3.1`.

## 4. Layout
```
scan_network.py  build_firewall.py          thin entry points
common/    models.py ports.py yaml_io.py policy.py runs.py     (3.6-compatible; NamedTuples)
scanner/   nmap_runner.py nmap_parser.py matcher.py report.py  (3.6-compatible)
builder/   topology.py groups.py ruleset.py render.py vendors/{__init__,nftables,vyos,pfsense}.py
templates/{nftables,vyos,pfsense}/   (pfsense/aliases.xml & pfsense/filter.xml provided)
policy.yaml (provided)  requirements-scan.txt  requirements-build.txt  README.md
```
Each package has `__init__.py`. `inputs/` and `runs/` are created by the operator/scripts. `README.md` is short: install, the two command lines, schema summary (section 5), workflow (section 1).

## 5. Data formats

### 5.1 `assumed.yaml`, `actual.yaml`, `new.yaml` (same format)
```yaml
web01:
  ip: 10.0.1.10
  generic: web            # string or list: [web, db]
  ports:
    "80/tcp": http
```
- Port key `"<port>/<tcp|udp>"` (string); value = service name. `ports` may be empty.
- Copy `ip`, `generic` (original type) and any extra keys unchanged. Duplicate IPs are an error.
- Sort ports by number then protocol (tcp first). Dump with `yaml.safe_dump(..., sort_keys=False, default_flow_style=False)`.
- `generic` matches `policy.yaml` roles case-insensitively (stripped) against role names and `aliases`; the original text is never rewritten.

### 5.2 `firewall.yaml`
```yaml
fw_core:
  type: vyos                      # pfsense | vyos | nftables
  options: {jump_rule: 500}       # optional, vendor-specific (section 8)
  interfaces:
    eth0: {generic_name: wan,      ip_addr: 203.0.113.2, ip_range: 203.0.113.0/24}
    eth1: {generic_name: internal, ip_addr: 10.0.0.1,    ip_range: 10.0.0.0/30}
    eth2: {generic_name: lan,      ip_addr: 10.0.1.1,    ip_range: 10.0.1.0/24}
```
- Top keys are firewall hostnames; `type` and `interfaces` required. `generic_name`: `wan` (outside), `internal` (between routers), `lan` (hosts). Types may differ per firewall.
- Interface keys are unique labels used to associate address ranges with `generic_name`; they are not emitted or used as firewall match conditions. The key names represent the actual interface names as would be seen in `ifconfig` or pfsense `interface` assignments.
- `ip_range` is an IPv4 network containing `ip_addr`. Optional `ipv6_ranges` is a list of IPv6 networks for that interface; use `[]` when it has no IPv6 network. LAN and internal networks for each firewall must not overlap across roles. Multiple interfaces may have the same `generic_name`.
- Validate `ip_addr` inside `ip_range`, known types, required keys, and `ipv6_ranges`. `panos`/`ftd` fail with an error naming supported types and saying they are planned, not implemented.

### 5.3 `policy.yaml` (provided; header comments explain it)
- `defaults`: `stateful` (always true), `icmp: allow`, `log_denied: true`, `ipv6: deny`; all implemented by every renderer.
- `services.<n>`: `ports` (`"port/proto"` or `"low-high/proto"`), `nmap_names` (aliases; on a shared name the service whose `ports` contain the port wins), `fixed_ports: true` (render policy ports as written, never learn from scans).
- `roles` (vocabulary for `generic`, with `aliases`). `access`: ordered `{name, from, to, services}`; `all` = every host; names unique, <=24 chars, `[a-z0-9_]`.
- Anything not allowed is denied and logged.
- Validate on load: services in `access` exist; roles in `from`/`to` exist or are `all`; names valid.

## 6. Script 1: `scan_network.py ASSUMED_YAML [--policy policy.yaml] [--output-dir runs]`
Exit 0 ok, 1 fatal (bad input, not root, nmap missing).

**Steps:** load/validate inputs (unknown roles = WARNING); check root and `shutil.which("nmap")`; create `runs/<YYYYMMDD-HHMMSS>/`, copy `assumed.yaml` into it; write target list; scan; parse; build `actual.yaml`; match/merge; write `new.yaml`, `diff.yaml`; print summary. All hosts are assumed up: no down-host handling, no discovery of unlisted hosts.

**nmap** (constants in `nmap_runner.py`; TCP and UDP run sequentially; argument lists only):
```
nmap -v -Pn -n -sS -sV --version-light -p- -T4 --min-rate 2000 --max-retries 2 --open -iL targets.txt -oX nmap/tcp.xml
nmap -v -Pn -n -sU -p <UDP_PORT_LIST> -T4 --max-retries 1 -iL targets.txt -oX nmap/udp.xml
```
`UDP_PORT_LIST` = sorted union of UDP ports in `assumed.yaml`, UDP ports of non-`fixed_ports` policy services, and `COMMON_UDP_PORTS` = 53, 67, 69, 123, 137, 138, 161, 162, 389, 500, 514, 520, 1194, 1701, 1812, 1813, 4500, 5060, 5353, 51820. No full-range UDP.
Stream stdout; log each `Discovered open port` line at INFO prefixed `[tcp]`/`[udp]`; log elapsed time per scan. Keep both XML files. If nmap fails, log stderr, exit 1.

**Parse** (`xml.etree`): per host IPv4 address; per port protocol, id, state, service `name`/`tunnel`. Map IPs to hostnames; ignore unlisted IPs. TCP and UDP keep `open`. UDP `open|filtered` is **unconfirmed**: usable only if that port was in `assumed.yaml` (kept in `new.yaml`, INFO). `filtered`/`closed` are never open.

**Service name** for an open port, in order: (1) the name `assumed.yaml` gave that `port/proto`; (2) a policy service whose `nmap_names` has nmap's name (if `tunnel` is `ssl`, try `<name>s`, `<name>ssl`, then `<name>`; ties broken by `ports`); (3) `unknown`.

**Per-host `new.yaml` ports:**
1. Start from `actual.yaml` open ports with the names above. `missing` = assumed ports not open; `extra` = open ports not assumed.
2. Moved by service: a `missing` port with service S is moved to any `extra` port of the same protocol whose name is S (method `service`; WARNING if one assumed port matches several).
3. Moved by elimination: if exactly one assumed and one open port remain unmatched on a protocol, pair them; the open port takes the assumed name (method `elimination`).
4. Remaining `extra` ports keep their resolved name. WARNING for each `unknown` (no firewall rule for it).
5. Remaining `missing` ports are not copied to `new.yaml`; they appear in `diff.yaml`.
6. Zero open ports: copy the assumed ports and WARNING. Unconfirmed UDP from `assumed.yaml` stays.

`actual.yaml` = scan result, no moves applied. `new.yaml` = merged. Both keep `ip`, `generic`, extra keys.

**`diff.yaml`** (every host, empty lists where nothing applies):
```yaml
web01:
  confirmed: ["80/tcp"]
  moved: [{from: "3306/tcp", to: "3307/tcp", service: mysql, method: service}]
  new: ["9000/tcp"]
  unknown: ["8123/tcp"]
  missing: ["25/tcp"]
  unconfirmed: ["123/udp"]
```
Console: INFO line per host; WARNING for moves, unknown ports, zero-port hosts, unrecognized roles; closing summary repeats all WARNINGs and prints paths of the three YAML files.

## 7. Script 2: `build_firewall.py NEW_YAML FIREWALL_YAML POLICY_YAML [--output-dir DIR] [--log-only]`
Default output `configs/` next to `NEW_YAML` (if it exists use `configs_2`, ...); files go to `<output-dir>/<firewall_hostname>/`.

**Pipeline:** load/validate (unknown roles are fatal here); resolve roles (hosts may have several); build per-firewall LAN and internal IP network sets from `ip_range` and `ipv6_ranges`; build identical host and port groups for every firewall; build the rule set; render per firewall via the registry; write files; summary. Do not filter host groups or allow rules based on the firewall interface to which a host is connected.

**Host groups:** one per role `h_<role>`; `h_all` for `all`. An access rule with several `from`/`to` roles gets `h_<rule>_src` / `h_<rule>_dst` (union). Multi-role hosts join each role's group. Members sorted numerically (`ipaddress`). Identical groups on every firewall.

**Port groups:** per access rule and protocol (tcp, udp) used: `p_<rule>_<proto>`, holding the union over the rule's services of (a) ports in `new.yaml` on hosts in the rule's `to` set whose service name (or alias) equals the service and protocol matches, and (b) policy ports of `fixed_ports` services (always, when the `to` set is non-empty). Ranges `low-high`. Skip the group and rule when ports, source or destination hosts are empty (INFO with reason). Names `[a-z0-9_]`, <=31 chars.

**Rule set** (`ruleset.py`, dataclasses):
```
HostGroup(name, members, description)   PortGroup(name, protocol, ports, description)
AllowRule(name, protocol, source_group, destination_group, port_group, description)
Ruleset(stateful, firewall, lan_networks, internal_networks, host_groups, port_groups, allow_rules,
        icmp_allowed, block_ipv6, log_denied, log_only, options)
```
Order, on every renderer: (1) forwarded IPv6 deny, logged; (2) stateful established/related; (3) ICMPv4 allowed `h_all` to `h_all`; (4) allow rules in policy order, tcp before udp, one logical rule per (access rule, protocol), named `<rule>_<proto>`; (5) final deny, logged. The IPv6 deny precedes state handling so established IPv6 flows cannot bypass the deny. `--log-only`: final rule logs and **accepts**, with a prominent WARNING at start and end that traffic is not denied. Only denied traffic is logged.

**Topology warnings:** host IP in no LAN range; hosts an access rule would separate that share one LAN or internal network (traffic does not cross the routed network boundary; list role pair and network); every `unknown` port or service name matching no policy service/alias (no rule generated).

**Registry** (`vendors/__init__.py`): dict filled by a `@register("name")` decorator. Renderer: `render(ruleset, firewall) -> dict[str, str]` (filename to text) and `file_mode`. `PLANNED = {"panos", "ftd"}`. A new vendor needs only a module, a template folder and registration.

## 8. Vendors
All: templates in `templates/<vendor>/`, one file per construct, numeric prefix sets order. Output deterministic, starts with a generated header comment (sources, firewall, `--log-only` flag, no timestamp). The policy scope is LAN-source to internal-destination and internal-source to LAN-destination network pairs. Match the scope by IP networks; no generated rule may match ingress or egress interfaces. Stateful, ICMP, allow, IPv6-deny, and final-deny actions apply only inside those pairs. Packets outside those pairs, including WAN and same-role traffic, are outside the generated policy. Host and port groups are identical on every firewall. Preserve operator-written rules except within the nftables table and pfsense xml, which is wholly replaced as specified below.

### 8.1 nftables
Output `nftables.nft`, loaded with `nft -f`. Manage only the existing `inet filter` table; do not create tables or alter other tables. Replace all contents of `inet filter` with the generated configuration, including a forward base chain named by `forward_chain` (default `forward`) that jumps to `fw_forward` and has an accept policy for packets that return outside the generated scope. Operator edits inside that table are intentionally replaced. Remove the `table` and `manual_include` options. The operator must ensure the table exists before loading the file. Use `flush`/`rebuild` commands.

| Construct | Notes |
|---|---|
| sets `fw_lan_nets` and `fw_internal_nets` | LAN and internal IPv4/IPv6 prefixes from `firewall.yaml`; address sets support network ranges |
| host sets | `type ipv4_addr`, one per host group |
| port sets | `type inet_service; flags interval;`, one per port group |
| chain `fw_state` | accept `ct state established,related` |
| chain `fw_v6` | log + drop IPv6 only for packets with endpoints in opposite LAN/internal IPv6 networks |
| chain `fw_icmp` | accept ICMPv4 |
| chain `fw_allow` | per allow rule: src set, dst set, `tcp`/`udp dport` set, `accept`, comment = rule name |
| chain `fw_deny` | `log prefix "fw_deny: "` then `drop` (`accept` with `--log-only`) |
| chain `fw_forward` | Return unless source and destination are in opposite LAN/internal network sets; then jump to `fw_v6`, `fw_state`, `fw_icmp`, `fw_allow`, `fw_deny`, in that order. Never inspect interface names. |

Illustrative: `add set inet filter h_web { type ipv4_addr; }`, `add element inet filter h_web { 10.0.1.10 }`, `add rule inet filter fw_allow ip saddr @h_x ip daddr @h_y tcp dport @p_z_tcp accept comment "z_tcp"`. Network-scope returns keep traffic outside the configured LAN/internal IP pairs outside this policy.

### 8.2 VyOS 1.5
Output `vyos.commands`: `set`/`delete` lines only, no `commit`/`save`. `options`: `jump_rule` (default 500, constant; first rule number of the IPv4 pair and rule number of the IPv6 rule), `manual_include` (default `inputs/manual/<firewall>.vyos`).

| Construct | Notes |
|---|---|
| delete section | delete the generated IP rules, chain, and this run's groups so re-imports are clean |
| network groups | LAN and internal IPv4/IPv6 prefixes, used as source/destination match groups |
| address groups / port groups | one per host / port group; port ranges `low-high` |
| chain `FW_INTERNAL` | default action drop with default logging (`accept` with `--log-only`); stateful accepts first; ICMP; allow rules numbered 10, 20, 30... |
| IPv4 | in `forward filter`, use two consecutive rules starting at `jump_rule` to `FW_INTERNAL` only for LAN-to-internal or internal-to-LAN source/destination network pairs |
| IPv6 rule | in `ipv6 forward filter` at `jump_rule`, drop + log only for the corresponding IPv6 network pairs |
| manual include | appended verbatim under a marker comment |

Known shapes: `set firewall group address-group h_web address 10.0.1.10`; `set firewall group network-group LAN_NET network 10.0.1.0/24`; `set firewall group port-group p_x_tcp port 80`; `... port 49152-65535`; `set firewall ipv4 name FW_INTERNAL rule 10 action accept`; `set firewall ipv4 forward filter rule 500 action jump`; `... rule 500 jump-target FW_INTERNAL`; `set firewall ipv4 forward filter rule 100 source group network-group BLOCKED_HOSTS`; `set firewall ipv4 forward filter rule 100 destination group network-group SENSITIVE_PORTS`. Do not create interface groups or use inbound/outbound interface matchers. Statefulness MUST be rules inside `FW_INTERNAL`, not `global-options`. 

### 8.3 pfSense CE 2.9.0
Output `filter.xml` and `aliases.xml`. Reference shapes: `templates/pfsense/filter.xml` and `templates/pfsense/aliases.xml`; use its element names and order exactly. Create these xml files from scratch, not preserving operator rules.

**Ownership:** every generated alias/rule `<descr>` starts with `fwgen:` (`GENERATED_MARKER`); descriptions use only letters, digits, spaces, `_`, `-`, `:`.

**Aliases** (appended to `<aliases>`): host groups `type host`, `address` = space-separated IPs; network groups `type network`, `address` = space-separated LAN/internal IPv4 or IPv6 prefixes; port groups `type port`, space-separated, ranges `low:high`; `detail` `||`-separated, one per member. Names: letters, digits, `_`, <=31 chars, not starting with a digit.

**Rules**, in order and are attached to the lan/internal interfaces, not with interface match conditions: (1) IPv6 block: `block`, `ipprotocol inet6`, no `<protocol>`, source/destination constrained to opposite LAN/internal IPv6 network aliases, `<log />`; (2) ICMP pass: `protocol icmp`, `icmptype any`, source and destination `h_all`; (3) allow rules: `pass`, `ipprotocol inet`, `protocol tcp|udp`, `statetype keep state`, source `<address>` host alias, destination `<address>` host alias + `<port>` port alias; (4) final deny: `block`, source/destination constrained to opposite LAN/internal IPv4 network aliases, `<log />` (`pass` with `<log />` under `--log-only`). Stateful, ICMP, and allow rules are also limited to those network pairs. Where a match requires the two alternatives (LAN-to-internal and internal-to-LAN), render one rule per alternative, adjacent to preserve logical ordering. Each rule has a unique numeric `<tracker>` (not an existing one) and `<created>`/`<updated>` with current time, username `fwgen`.

**Insertion point:** `<filter>` is flat and rules evaluate top down in document order for each interface. `<aliases>` is flat and aliases evaluate top down in document order for network, port, and host types.

## 9. Templates
Jinja2 `Environment`: `StrictUndefined`, `trim_blocks=True`, `lstrip_blocks=True`, `keep_trailing_newline=True`; autoescape on for XML, off for text. One file per construct, number-prefixed, ending in target type (e.g. `30_host_sets.nft.j2`); the renderer discovers and orders them, no hard-coded count. Templates get the `Ruleset` and `Firewall` and contain no policy logic (no filtering, dedup, decisions); Python prepares everything.

## 10. Console
Plain `LEVEL: message`. Both scripts end with a summary repeating every WARNING and listing files written. Script 2 prints per firewall: type, counts of host groups, port groups, rules, output files. Never print secrets.

## 11. Acceptance (operator verifies manually; write no tests)
Script 1: (1) one moved and one unchanged service: `new.yaml` has both, original name on the moved port, `diff.yaml` records the move and method; (2) outputs load as 5.1, `ip`/`generic`/extra keys unchanged; (3) raw XML kept, nothing overwritten across runs; (4) non-root or no nmap exits 1 with a clear message; (5) runs on 3.6 with only PyYAML.
Script 2: (6) each of `pfsense`, `vyos`, `nftables` produces section 8 files, unimplemented types fail cleanly; (7) same inputs give identical logical group/rule counts across vendors; (8) rules use only `new.yaml` ports plus `fixed_ports`, never `unknown`; (9) `--log-only` changes the final deny to log-and-accept on every vendor; (10) nftables output replaces only the contents of an existing `inet filter` table, creates no tables, and leaves other tables untouched; (11) generated policy matches IP networks and contains no interface match conditions; packets outside LAN/internal network pairs are unaffected; (12) pfSense creates new configs through filter.xml and aliases.xml

## 12. Prerequisites
`policy.yaml`, `templates/pfsense/aliases.xml`, and  `templates/pfsense/filter.xml`  must exist, else stop and ask.
