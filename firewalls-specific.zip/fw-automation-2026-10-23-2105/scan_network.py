"""Scan assumed hosts and write actual, merged, and difference YAML files."""

import argparse
import ctypes
import ipaddress
import logging
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from common.models import Policy, ScanHost
from common.policy import load_policy, role_alias_map
from common.ports import parse_port_key
from common.runs import create_run_directory
from common.yaml_io import dump_yaml, load_yaml
from scanner.matcher import match_hosts
from scanner.nmap_parser import parse_nmap_xml
from scanner.nmap_runner import NmapError, build_udp_port_list, run_scans
from scanner.report import ScanReport


def configure_logging() -> logging.Logger:
    """Configure plain console logging and return the script logger."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    return logging.getLogger("scan_network")


def is_administrator() -> bool:
    """Check for root on Unix or an elevated administrator token on Windows."""
    if os.name == "nt":
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            return False
    get_effective_uid = getattr(os, "geteuid", None)
    return get_effective_uid is not None and get_effective_uid() == 0


def load_assumed_hosts(path: Path) -> Dict[str, ScanHost]:
    """Load and strictly validate assumed host records."""
    raw = load_yaml(path)
    if not isinstance(raw, dict) or not raw:
        raise ValueError("assumed YAML must be a non-empty mapping of hostnames")
    hosts = {}
    seen_ips = set()
    for hostname, entry in raw.items():
        if not isinstance(hostname, str) or not hostname.strip():
            raise ValueError("assumed hostnames must be non-empty strings")
        if not isinstance(entry, dict):
            raise ValueError("assumed host {!r} must be a mapping".format(hostname))
        for required_key in ("ip", "generic", "ports"):
            if required_key not in entry:
                raise ValueError("assumed host {!r} is missing {!r}".format(hostname, required_key))
        ip_value = entry["ip"]
        if not isinstance(ip_value, str):
            raise ValueError("assumed host {!r} ip must be a string".format(hostname))
        try:
            parsed_ip = ipaddress.IPv4Address(ip_value)
        except ipaddress.AddressValueError as error:
            raise ValueError("assumed host {!r} ip must be IPv4: {}".format(hostname, error))
        if parsed_ip in seen_ips:
            raise ValueError("duplicate assumed IPv4 address {!r}".format(ip_value))
        seen_ips.add(parsed_ip)
        generic = entry["generic"]
        if isinstance(generic, str):
            if not generic.strip():
                raise ValueError("assumed host {!r} generic must be non-empty".format(hostname))
        elif isinstance(generic, list):
            if not generic or any(not isinstance(role, str) or not role.strip() for role in generic):
                raise ValueError("assumed host {!r} generic list must contain non-empty strings".format(hostname))
        else:
            raise ValueError("assumed host {!r} generic must be a string or list of strings".format(hostname))
        ports_value = entry["ports"]
        if not isinstance(ports_value, dict):
            raise ValueError("assumed host {!r} ports must be a mapping".format(hostname))
        ports = {}
        for port_key, service_name in ports_value.items():
            if not isinstance(port_key, str):
                raise ValueError("assumed host {!r} port keys must be strings".format(hostname))
            parse_port_key(port_key)
            if not isinstance(service_name, str) or not service_name.strip():
                raise ValueError("assumed host {!r} service names must be non-empty strings".format(hostname))
            ports[port_key] = service_name
        copied_entry = dict(entry)
        hosts[hostname] = ScanHost(
            name=hostname,
            ip=ip_value,
            generic=generic,
            ports=ports,
            raw=copied_entry,
        )
    return hosts


def find_unknown_roles(hosts: Dict[str, ScanHost], policy: Policy) -> List[str]:
    """Return warnings for generic role names absent from policy vocabulary."""
    alias_map = role_alias_map(policy)
    warnings = []
    for host in hosts.values():
        generic_values = host.generic if isinstance(host.generic, list) else [host.generic]
        for value in generic_values:
            if value.strip().lower() not in alias_map:
                warnings.append(
                    "{} has unrecognized role {!r}".format(host.name, value)
                )
    return warnings


def build_argument_parser() -> argparse.ArgumentParser:
    """Create the scanner command-line parser."""
    parser = argparse.ArgumentParser(description="Scan assumed hosts and reconcile their service ports.")
    parser.add_argument("assumed_yaml", type=Path, help="path to assumed.yaml")
    parser.add_argument("--policy", type=Path, default=Path("policy.yaml"), help="policy YAML path")
    parser.add_argument("--output-dir", type=Path, default=Path("runs"), help="run output root")
    return parser


def run_scan(assumed_path: Path, policy_path: Path, output_root: Path,
             logger: logging.Logger) -> None:
    """Run validation, nmap scans, matching, and output generation."""
    if not assumed_path.is_file():
        raise ValueError("assumed YAML does not exist: {}".format(assumed_path))
    if not policy_path.is_file():
        raise ValueError("policy YAML does not exist: {}".format(policy_path))
    hosts = load_assumed_hosts(assumed_path)
    policy = load_policy(policy_path)
    report = ScanReport(logger)
    for warning in find_unknown_roles(hosts, policy):
        report.warning(warning)
    if not is_administrator():
        report.finish([])
        raise ValueError("scan_network.py must run as root/Administrator")
    nmap_path = shutil.which("nmap")
    if nmap_path is None:
        report.finish([])
        raise ValueError("nmap was not found on PATH")

    run_directory = create_run_directory(output_root)
    shutil.copy2(str(assumed_path), str(run_directory / "assumed.yaml"))
    targets_path = run_directory / "targets.txt"
    with targets_path.open("w", encoding="utf-8", newline="\n") as target_file:
        for host in hosts.values():
            target_file.write(host.ip + "\n")

    udp_ports = build_udp_port_list(hosts, policy)
    try:
        run_scans(run_directory, targets_path, udp_ports, logger)
    except NmapError:
        report.finish([])
        raise

    try:
        tcp_results = parse_nmap_xml(run_directory / "nmap" / "tcp.xml")
        udp_results = parse_nmap_xml(run_directory / "nmap" / "udp.xml")
    except ValueError:
        report.finish([])
        raise
    scan_results = _merge_scan_results(tcp_results, udp_results)
    result = match_hosts(hosts, scan_results, policy)
    for warning in result.warnings:
        report.warning(warning)
    for host_name in hosts:
        host_scan = scan_results.get(hosts[host_name].ip, {})
        open_count = sum(1 for scan_port in host_scan.values() if scan_port.state == "open")
        unconfirmed_count = sum(
            1 for port_key, scan_port in host_scan.items()
            if scan_port.state == "open|filtered"
            and port_key in hosts[host_name].ports
            and port_key.endswith("/udp")
        )
        report.host(host_name, open_count, unconfirmed_count)
        for port_key, scan_port in host_scan.items():
            if (scan_port.state == "open|filtered"
                    and port_key in hosts[host_name].ports
                    and port_key.endswith("/udp")):
                logger.info("%s: retaining unconfirmed UDP port %s from assumed.yaml", host_name, port_key)

    actual_path = run_directory / "actual.yaml"
    new_path = run_directory / "new.yaml"
    diff_path = run_directory / "diff.yaml"
    dump_yaml(actual_path, result.actual)
    dump_yaml(new_path, result.new)
    dump_yaml(diff_path, result.diff)
    report.finish([actual_path, new_path, diff_path])


def _merge_scan_results(first: Dict[str, Dict[str, Any]],
                        second: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Merge TCP and UDP XML data, preferring confirmed open states."""
    merged = {}
    for source in (first, second):
        for host_ip, ports in source.items():
            host_ports = merged.setdefault(host_ip, {})
            for port_key, scan_port in ports.items():
                previous = host_ports.get(port_key)
                if previous is None or (previous.state != "open" and scan_port.state == "open"):
                    host_ports[port_key] = scan_port
    return merged


def main(argv: Optional[List[str]] = None) -> int:
    """Run the scanner CLI and return its process status."""
    logger = configure_logging()
    parser = build_argument_parser()
    arguments = parser.parse_args(argv)
    try:
        run_scan(arguments.assumed_yaml, arguments.policy, arguments.output_dir, logger)
    except (OSError, ValueError, NmapError) as error:
        logger.error("%s", error)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
