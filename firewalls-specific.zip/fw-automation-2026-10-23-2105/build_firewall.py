"""Build vendor firewall configurations from scan, inventory, and policy YAML."""

import argparse
import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional

from common.policy import load_policy
from builder.groups import build_groups
from builder.render import create_output_directory, render_all, write_outputs
from builder.ruleset import Ruleset, make_ruleset
from builder.topology import Firewall, build_topology_warnings, load_firewalls, load_new_hosts


LOG_ONLY_WARNING = (
    "LOG-ONLY MODE: final deny actions will accept traffic; this run will not deny disallowed traffic"
)


class BuildSummary:
    """Collect warnings and summarize files and counts for one builder run."""

    def __init__(self, logger: logging.Logger) -> None:
        """Create a builder summary for this invocation."""
        self.logger = logger
        self.warnings = []  # type: List[str]
        self.files_written = []  # type: List[Path]

    def warning(self, message: str) -> None:
        """Log and retain a warning for the closing summary."""
        self.warnings.append(message)
        self.logger.warning(message)

    def finish(self, rulesets: Dict[str, Ruleset]) -> None:
        """Print the closing warning list, counts, and output paths."""
        self.logger.info("Build summary:")
        for warning in self.warnings:
            self.logger.warning(warning)
        for hostname in sorted(rulesets):
            ruleset = rulesets[hostname]
            file_paths = [path for path in self.files_written if path.parent.name == hostname]
            self.logger.info(
                "%s: type=%s host_groups=%d port_groups=%d rules=%d output_files=%d",
                hostname,
                ruleset.firewall.type,
                len(ruleset.host_groups),
                len(ruleset.port_groups),
                ruleset.logical_rule_count,
                len(file_paths),
            )
        for path in self.files_written:
            self.logger.info("Output: %s", path)


def configure_logging() -> logging.Logger:
    """Configure plain console logging and return the builder logger."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    return logging.getLogger("build_firewall")


def build_argument_parser() -> argparse.ArgumentParser:
    """Create the firewall builder command-line parser."""
    parser = argparse.ArgumentParser(description="Build firewall configurations from YAML policy inputs.")
    parser.add_argument("new_yaml", type=Path, help="path to scanner new.yaml")
    parser.add_argument("firewall_yaml", type=Path, help="path to firewall.yaml")
    parser.add_argument("policy_yaml", type=Path, help="path to policy.yaml")
    parser.add_argument("--output-dir", type=Path, default=None, help="configuration output directory")
    parser.add_argument("--log-only", action="store_true", help="log disallowed traffic and accept it")
    return parser


def run_build(new_yaml_path: Path, firewall_yaml_path: Path, policy_yaml_path: Path,
              requested_output: Optional[Path], log_only: bool,
              logger: logging.Logger) -> int:
    """Validate inputs, build renderer-independent rulesets, and write outputs."""
    summary = BuildSummary(logger)
    if log_only:
        summary.warning(LOG_ONLY_WARNING)
    rulesets = {}
    try:
        for input_path, label in (
            (new_yaml_path, "new.yaml"),
            (firewall_yaml_path, "firewall.yaml"),
            (policy_yaml_path, "policy.yaml"),
        ):
            if not input_path.is_file():
                raise ValueError("{} does not exist: {}".format(label, input_path))

        policy = load_policy(policy_yaml_path)
        hosts = load_new_hosts(new_yaml_path, policy)
        firewalls = load_firewalls(firewall_yaml_path)
        for warning in build_topology_warnings(hosts, firewalls, policy):
            summary.warning(warning)

        groups = build_groups(hosts, policy, logger)
        for firewall in firewalls.values():
            rulesets[firewall.hostname] = make_ruleset(
                firewall=firewall,
                host_groups=groups.host_groups,
                port_groups=groups.port_groups,
                allow_rules=groups.allow_rules,
                log_only=log_only,
            )

        rendered = render_all(rulesets)
        output_root = create_output_directory(new_yaml_path, requested_output)
        write_outputs(output_root, rendered, logger, summary.files_written)
        return 0
    except (OSError, ValueError, TypeError) as error:
        logger.error("%s", error)
        return 1
    finally:
        if log_only:
            logger.warning(LOG_ONLY_WARNING)
        summary.finish(rulesets)


def main(argv: Optional[List[str]] = None) -> int:
    """Run the builder CLI and return its process status."""
    logger = configure_logging()
    parser = build_argument_parser()
    arguments = parser.parse_args(argv)
    return run_build(
        arguments.new_yaml,
        arguments.firewall_yaml,
        arguments.policy_yaml,
        arguments.output_dir,
        arguments.log_only,
        logger,
    )


if __name__ == "__main__":
    sys.exit(main())
