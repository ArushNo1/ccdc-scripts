"""Load builder inputs and derive address-based firewall topology."""

from dataclasses import dataclass
import ipaddress
from pathlib import Path
from typing import Dict, List, Tuple, Union

from common.models import Policy
from common.ports import parse_port_key
from common.policy import role_alias_map
from common.yaml_io import load_yaml


IPNetwork = Union[ipaddress.IPv4Network, ipaddress.IPv6Network]


@dataclass(frozen=True)
class BuildHost:
    """A validated new.yaml host with canonical policy roles."""

    name: str
    address: ipaddress.IPv4Address
    roles: Tuple[str, ...]
    ports: Dict[str, str]


@dataclass(frozen=True)
class FirewallInterface:
    """An inventory interface and its declared networks."""

    name: str
    generic_name: str
    ip_addr: ipaddress.IPv4Address
    ip_range: ipaddress.IPv4Network
    ipv6_ranges: Tuple[ipaddress.IPv6Network, ...]


@dataclass(frozen=True)
class Firewall:
    """Validated firewall inventory entry and derived network sets."""

    hostname: str
    type: str
    options: Dict[str, object]
    interfaces: Tuple[FirewallInterface, ...]
    lan_networks: Tuple[IPNetwork, ...]
    internal_networks: Tuple[IPNetwork, ...]


def load_new_hosts(path: Path, policy: Policy) -> Dict[str, BuildHost]:
    """Load new.yaml and resolve each host's generic values to policy roles."""
    raw_hosts = load_yaml(path)
    if not isinstance(raw_hosts, dict) or not raw_hosts:
        raise ValueError("new.yaml must be a non-empty mapping of hostnames")
    aliases = role_alias_map(policy)
    if "all" in aliases:
        raise ValueError("policy role name or alias 'all' is reserved for the built-in all-host group")
    alias_owners = {}
    for alias, role_name in aliases.items():
        previous = alias_owners.get(alias)
        if previous is not None and previous != role_name:
            raise ValueError("policy role alias {!r} is shared by {!r} and {!r}".format(
                alias, previous, role_name
            ))
        alias_owners[alias] = role_name

    hosts = {}
    seen_addresses = set()
    for hostname, raw_host in raw_hosts.items():
        if not isinstance(hostname, str) or not hostname.strip():
            raise ValueError("new.yaml hostnames must be non-empty strings")
        if not isinstance(raw_host, dict):
            raise ValueError("new.yaml host {!r} must be a mapping".format(hostname))
        for required_key in ("ip", "generic", "ports"):
            if required_key not in raw_host:
                raise ValueError("new.yaml host {!r} is missing {!r}".format(hostname, required_key))
        ip_value = raw_host["ip"]
        if not isinstance(ip_value, str):
            raise ValueError("new.yaml host {!r} ip must be a string".format(hostname))
        try:
            address = ipaddress.IPv4Address(ip_value)
        except ipaddress.AddressValueError as error:
            raise ValueError("new.yaml host {!r} ip must be IPv4: {}".format(hostname, error))
        if address in seen_addresses:
            raise ValueError("duplicate new.yaml IPv4 address {!r}".format(ip_value))
        seen_addresses.add(address)

        raw_roles = raw_host["generic"]
        role_values = raw_roles if isinstance(raw_roles, list) else [raw_roles]
        if not role_values or any(not isinstance(value, str) or not value.strip() for value in role_values):
            raise ValueError("new.yaml host {!r} generic must be a string or non-empty list of strings".format(hostname))
        resolved_roles = []
        for value in role_values:
            canonical = aliases.get(value.strip().lower())
            if canonical is None:
                raise ValueError("new.yaml host {!r} has unknown role {!r}".format(hostname, value))
            if canonical not in resolved_roles:
                resolved_roles.append(canonical)

        raw_ports = raw_host["ports"]
        if not isinstance(raw_ports, dict):
            raise ValueError("new.yaml host {!r} ports must be a mapping".format(hostname))
        ports = {}
        for port_key, service_name in raw_ports.items():
            if not isinstance(port_key, str):
                raise ValueError("new.yaml host {!r} port keys must be strings".format(hostname))
            parse_port_key(port_key)
            if not isinstance(service_name, str) or not service_name.strip():
                raise ValueError("new.yaml host {!r} service names must be non-empty strings".format(hostname))
            ports[port_key] = service_name
        hosts[hostname] = BuildHost(hostname, address, tuple(resolved_roles), ports)
    return hosts


def load_firewalls(path: Path) -> Dict[str, Firewall]:
    """Load firewall.yaml and validate interface address assignments."""
    raw_firewalls = load_yaml(path)
    if not isinstance(raw_firewalls, dict) or not raw_firewalls:
        raise ValueError("firewall.yaml must be a non-empty mapping of firewall hostnames")
    firewalls = {}
    supported = ("pfsense", "vyos", "nftables")
    for hostname, raw_firewall in raw_firewalls.items():
        if not isinstance(hostname, str) or not hostname.strip() or hostname in (".", ".."):
            raise ValueError("firewall hostnames must be safe, non-empty directory names")
        if any(character in hostname for character in "/\\<>:\"|?*"):
            raise ValueError("firewall hostname {!r} contains a character unsafe for an output directory".format(
                hostname
            ))
        if hostname.endswith((" ", ".")):
            raise ValueError("firewall hostname {!r} cannot end in a space or period".format(hostname))
        if not isinstance(raw_firewall, dict):
            raise ValueError("firewall {!r} must be a mapping".format(hostname))
        for required_key in ("type", "interfaces"):
            if required_key not in raw_firewall:
                raise ValueError("firewall {!r} is missing {!r}".format(hostname, required_key))
        vendor = raw_firewall["type"]
        if not isinstance(vendor, str):
            raise ValueError("firewall {!r} type must be a string".format(hostname))
        if vendor not in supported:
            supported_text = ", ".join(supported)
            if vendor in ("panos", "ftd"):
                raise ValueError("firewall type {!r} is planned, not implemented; supported types: {}".format(
                    vendor, supported_text
                ))
            raise ValueError("unknown firewall type {!r}; supported types: {}".format(vendor, supported_text))
        options = raw_firewall.get("options", {})
        if not isinstance(options, dict):
            raise ValueError("firewall {!r} options must be a mapping".format(hostname))
        raw_interfaces = raw_firewall["interfaces"]
        if not isinstance(raw_interfaces, dict) or not raw_interfaces:
            raise ValueError("firewall {!r} interfaces must be a non-empty mapping".format(hostname))
        interfaces = []
        for interface_name, raw_interface in raw_interfaces.items():
            interfaces.append(_parse_interface(hostname, interface_name, raw_interface))
        lan_networks = _networks_for_role(interfaces, "lan")
        internal_networks = _networks_for_role(interfaces, "internal")
        _validate_role_networks(hostname, lan_networks, internal_networks)
        firewalls[hostname] = Firewall(
            hostname=hostname,
            type=vendor,
            options=dict(options),
            interfaces=tuple(interfaces),
            lan_networks=lan_networks,
            internal_networks=internal_networks,
        )
    return firewalls


def build_topology_warnings(hosts: Dict[str, BuildHost], firewalls: Dict[str, Firewall],
                            policy: Policy) -> List[str]:
    """Return warnings for out-of-LAN hosts, non-routed role pairs, and unknown services."""
    warnings = []
    for firewall in firewalls.values():
        for host in hosts.values():
            if not _address_in_networks(host.address, firewall.lan_networks):
                warnings.append("{} on {} is not in any LAN range".format(host.name, firewall.hostname))
        warnings.extend(_shared_network_warnings(hosts, firewall, policy))

    known_service_names = set()
    for service in policy.services.values():
        known_service_names.add(service.name.strip().lower())
        known_service_names.update(name.strip().lower() for name in service.nmap_names)
    for host in hosts.values():
        for port_key, service_name in host.ports.items():
            if service_name.strip().lower() not in known_service_names:
                warnings.append(
                    "{} port {} has unknown service {!r}; no rule will be generated".format(
                        host.name, port_key, service_name
                    )
                )
    return warnings


def _parse_interface(hostname: str, name: object, raw: object) -> FirewallInterface:
    """Validate one interface, its IPv4 range, and optional IPv6 ranges."""
    if not isinstance(name, str) or not name.strip():
        raise ValueError("firewall {!r} interface names must be non-empty strings".format(hostname))
    if not isinstance(raw, dict):
        raise ValueError("firewall {!r} interface {!r} must be a mapping".format(hostname, name))
    for required_key in ("generic_name", "ip_addr", "ip_range"):
        if required_key not in raw:
            raise ValueError("firewall {!r} interface {!r} is missing {!r}".format(hostname, name, required_key))
    generic_name = raw["generic_name"]
    if generic_name not in ("wan", "internal", "lan"):
        raise ValueError("firewall {!r} interface {!r} generic_name must be wan, internal, or lan".format(
            hostname, name
        ))
    if not isinstance(raw["ip_addr"], str) or not isinstance(raw["ip_range"], str):
        raise ValueError("firewall {!r} interface {!r} ip_addr and ip_range must be strings".format(hostname, name))
    try:
        ip_addr = ipaddress.IPv4Address(raw["ip_addr"])
    except ValueError as error:
        raise ValueError("firewall {!r} interface {!r}: invalid IPv4 address: {}".format(hostname, name, error))
    try:
        ip_range = ipaddress.IPv4Network(raw["ip_range"], strict=True)
    except ValueError as error:
        raise ValueError("firewall {!r} interface {!r}: invalid IPv4 network: {}".format(hostname, name, error))
    if ip_addr not in ip_range:
        raise ValueError("firewall {!r} interface {!r} ip_addr is outside ip_range".format(hostname, name))
    raw_ipv6_ranges = raw.get("ipv6_ranges", [])
    if not isinstance(raw_ipv6_ranges, list):
        raise ValueError("firewall {!r} interface {!r} ipv6_ranges must be a list".format(hostname, name))
    ipv6_ranges = []
    for value in raw_ipv6_ranges:
        if not isinstance(value, str):
            raise ValueError("firewall {!r} interface {!r} IPv6 ranges must be strings".format(hostname, name))
        try:
            ipv6_ranges.append(ipaddress.IPv6Network(value, strict=True))
        except ValueError as error:
            raise ValueError("firewall {!r} interface {!r}: invalid IPv6 network: {}".format(hostname, name, error))
    return FirewallInterface(name, generic_name, ip_addr, ip_range, tuple(ipv6_ranges))


def _networks_for_role(interfaces: List[FirewallInterface], role: str) -> Tuple[IPNetwork, ...]:
    """Collect and numerically sort unique IPv4/IPv6 networks for a role."""
    networks = set()
    for interface in interfaces:
        if interface.generic_name != role:
            continue
        networks.add(interface.ip_range)
        networks.update(interface.ipv6_ranges)
    return tuple(sorted(networks, key=_network_sort_key))


def _validate_role_networks(hostname: str, lan_networks: Tuple[IPNetwork, ...],
                            internal_networks: Tuple[IPNetwork, ...]) -> None:
    """Reject LAN/internal prefixes that overlap within an address family."""
    for lan_network in lan_networks:
        for internal_network in internal_networks:
            if lan_network.version == internal_network.version and lan_network.overlaps(internal_network):
                raise ValueError(
                    "firewall {!r} LAN network {} overlaps internal network {}".format(
                        hostname, lan_network, internal_network
                    )
                )


def _shared_network_warnings(hosts: Dict[str, BuildHost], firewall: Firewall,
                             policy: Policy) -> List[str]:
    """Find policy source/destination hosts sharing a configured network."""
    role_aliases = role_alias_map(policy)
    warnings = set()
    networks = firewall.lan_networks + firewall.internal_networks
    for access in policy.access:
        source_roles = _canonical_roles(access.from_roles, role_aliases)
        destination_roles = _canonical_roles(access.to_roles, role_aliases)
        for source_role in source_roles:
            source_hosts = _hosts_for_role(hosts, source_role)
            for destination_role in destination_roles:
                destination_hosts = _hosts_for_role(hosts, destination_role)
                for source_host in source_hosts:
                    for destination_host in destination_hosts:
                        if source_host.address == destination_host.address:
                            continue
                        for network in networks:
                            if (network.version == source_host.address.version
                                    and source_host.address in network
                                    and destination_host.address in network):
                                warnings.add(
                                    "{} access {} ({} -> {}) shares network {}; traffic does not cross a routed boundary".format(
                                        firewall.hostname, access.name, source_role, destination_role, network
                                    )
                                )
    return sorted(warnings)


def _canonical_roles(role_values: Tuple[str, ...], aliases: Dict[str, str]) -> Tuple[str, ...]:
    """Normalize policy roles, preserving the built-in all role."""
    resolved = []
    for value in role_values:
        normalized = value.strip().lower()
        canonical = "all" if normalized == "all" else aliases[normalized]
        if canonical not in resolved:
            resolved.append(canonical)
    return tuple(resolved)


def _hosts_for_role(hosts: Dict[str, BuildHost], role: str) -> List[BuildHost]:
    """Return hosts selected by a role or by the all pseudo-role."""
    if role == "all":
        return list(hosts.values())
    return [host for host in hosts.values() if role in host.roles]


def _address_in_networks(address: ipaddress.IPv4Address, networks: Tuple[IPNetwork, ...]) -> bool:
    """Return whether an IPv4 address belongs to any configured network."""
    return any(network.version == address.version and address in network for network in networks)


def _network_sort_key(network: IPNetwork) -> Tuple[int, int, int]:
    """Sort prefixes by address family, network address, and prefix length."""
    return network.version, int(network.network_address), network.prefixlen
