"""Render registry output and write it into a unique config directory."""

import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from builder.ruleset import Ruleset
from builder.vendors import Renderer, get_renderer


def render_all(rulesets: Dict[str, Ruleset]) -> Dict[str, Tuple[Renderer, Dict[str, str]]]:
    """Render all firewalls before creating output directories."""
    rendered = {}
    for hostname, ruleset in rulesets.items():
        renderer = get_renderer(ruleset.firewall.type)
        files = renderer.render(ruleset, ruleset.firewall)
        if not isinstance(files, dict) or not files:
            raise ValueError("renderer for {} returned no output files".format(hostname))
        for filename, contents in files.items():
            if not isinstance(filename, str) or not filename or Path(filename).name != filename:
                raise ValueError("renderer for {} returned an unsafe filename {!r}".format(hostname, filename))
            if not isinstance(contents, str):
                raise ValueError("renderer output {} for {} must be text".format(filename, hostname))
        rendered[hostname] = renderer, files
    return rendered


def create_output_directory(new_yaml_path: Path, requested_path: Optional[Path] = None) -> Path:
    """Create a non-existing output root, using the specified default naming."""
    if requested_path is None:
        base_path = new_yaml_path.parent / "configs"
    else:
        base_path = requested_path
    candidate = base_path
    suffix = 2
    while candidate.exists():
        candidate = base_path.parent / "{}_{}".format(base_path.name, suffix)
        suffix += 1
    candidate.mkdir(parents=True)
    return candidate


def write_outputs(output_root: Path,
                  rendered: Dict[str, Tuple[Renderer, Dict[str, str]]],
                  logger: logging.Logger,
                  all_written_paths: Optional[List[Path]] = None) -> Dict[str, List[Path]]:
    """Write deterministic vendor output files with each renderer's mode."""
    written = {}
    for hostname in sorted(rendered):
        renderer, files = rendered[hostname]
        firewall_directory = output_root / hostname
        firewall_directory.mkdir()
        written_paths = []
        for filename in sorted(files):
            output_path = firewall_directory / filename
            with output_path.open("w", encoding="utf-8", newline="\n") as output_file:
                output_file.write(files[filename])
            os.chmod(str(output_path), renderer.file_mode)
            written_paths.append(output_path)
            if all_written_paths is not None:
                all_written_paths.append(output_path)
            logger.info("Wrote %s", output_path)
        written[hostname] = written_paths
    return written
