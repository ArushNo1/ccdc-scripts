"""Resolve policy hosts and construct deterministic host and port groups."""

import ipaddress
import logging
import re
from typing import Dict, Iterable, List, Tuple

from common.models import Policy, PolicyAccess, PolicyService
from common.policy import role_alias_map
from common.ports import parse_port_key
from builder.ruleset import AllowRule, HostGroup, PortGroup
from builder.topology import BuildHost


GROUP_NAME_PATTERN = re.compile(r"^[a-z0-9_]{1,31}$")
PROTOCOL_ORDER = ("tcp", "udp")


class GroupBuildResult:
    """Host groups, port groups, and logical allow rules."""

    def __init__(self, host_groups: Tuple[HostGroup, ...], port_groups: Tuple[PortGroup, ...],
                 allow_rules: Tuple[AllowRule, ...]) -> None:
        """Store the deterministic results of group construction."""
        self.host_groups = host_groups
        self.port_groups = port_groups
        self.allow_rules = allow_rules


def build_groups(hosts: Dict[str, BuildHost], policy: Policy,
                 logger: logging.Logger) -> GroupBuildResult:
    """Build identical role, composite, and per-rule service groups."""
    role_aliases = role_alias_map(policy)
    host_members_by_role = _members_by_role(hosts, policy)
    host_groups = {}
    group_members = {}

    for role_name, members in host_members_by_role.items():
        group_name = _checked_name("h_" + role_name)
        _add_group(host_groups, group_members, group_name, members,
                   "Hosts in role {}".format(role_name))
    all_members = _sorted_addresses([host.address for host in hosts.values()])
    _add_group(host_groups, group_members, "h_all", all_members, "All hosts")

    access_groups = {}
    for access in policy.access:
        from_roles = _canonical_roles(access.from_roles, role_aliases)
        to_roles = _canonical_roles(access.to_roles, role_aliases)
        source_name, source_members = _access_host_group(
            access.name, "src", from_roles, host_members_by_role, group_members, host_groups
        )
        destination_name, destination_members = _access_host_group(
            access.name, "dst", to_roles, host_members_by_role, group_members, host_groups
        )
        access_groups[access.name] = (
            source_name, source_members, destination_name, destination_members
        )

    port_groups = {}
    allow_rules = []
    for access in policy.access:
        source_name, source_members, destination_name, destination_members = access_groups[access.name]
        if not source_members:
            logger.info("Skipping access %s: source host group is empty", access.name)
            continue
        if not destination_members:
            logger.info("Skipping access %s: destination host group is empty", access.name)
            continue
        for protocol in PROTOCOL_ORDER:
            intervals = _ports_for_access(access, protocol, hosts, policy, destination_members)
            if not intervals:
                logger.info("Skipping access %s/%s: no matching ports", access.name, protocol)
                continue
            group_name = _checked_name("p_{}_{}".format(access.name, protocol))
            port_group = PortGroup(
                name=group_name,
                protocol=protocol,
                ports=tuple(_format_intervals(intervals)),
                description="Ports for {} {}".format(access.name, protocol),
            )
            if group_name in port_groups:
                raise ValueError("duplicate generated port group name {!r}".format(group_name))
            port_groups[group_name] = port_group
            allow_rules.append(AllowRule(
                name="{}_{}".format(access.name, protocol),
                protocol=protocol,
                source_group=source_name,
                destination_group=destination_name,
                port_group=group_name,
                description="{} {} access".format(access.name, protocol),
            ))

    return GroupBuildResult(
        host_groups=tuple(host_groups[name] for name in sorted(host_groups)),
        port_groups=tuple(port_groups[name] for name in sorted(port_groups)),
        allow_rules=tuple(allow_rules),
    )


def _members_by_role(hosts: Dict[str, BuildHost], policy: Policy) -> Dict[str, Tuple[str, ...]]:
    """Return all policy role groups, retaining groups with no members."""
    members = {role_name: [] for role_name in policy.roles}
    for host in hosts.values():
        for role_name in host.roles:
            members[role_name].append(host.address)
    return {
        role_name: _sorted_addresses(addresses)
        for role_name, addresses in members.items()
    }


def _access_host_group(rule_name: str, direction: str, roles: Tuple[str, ...],
                       role_members: Dict[str, Tuple[str, ...]],
                       group_members: Dict[str, Tuple[str, ...]],
                       host_groups: Dict[str, HostGroup]) -> Tuple[str, Tuple[str, ...]]:
    """Use a role group for one role or create a union group for many roles."""
    if len(roles) == 1 and roles[0] == "all":
        return "h_all", group_members["h_all"]
    if len(roles) == 1:
        group_name = "h_" + roles[0]
        return group_name, group_members[group_name]
    members = _sorted_addresses(
        address
        for role_name in roles
        for address in role_members[role_name]
    )
    base_name = _checked_name("h_{}_{}".format(rule_name, direction))
    if not members:
        return base_name, members
    group_name = _unique_group_name(base_name, members, group_members)
    if group_name not in host_groups:
        _add_group(
            host_groups,
            group_members,
            group_name,
            members,
            "Hosts selected by {} {} roles".format(rule_name, direction),
        )
    return group_name, group_members[group_name]


def _ports_for_access(access: PolicyAccess, protocol: str,
                      hosts: Dict[str, BuildHost], policy: Policy,
                      destination_members: Tuple[str, ...]) -> List[Tuple[int, int]]:
    """Union scanned service ports and fixed policy ranges for one protocol."""
    destination_set = set(destination_members)
    service_entries = [policy.services[name] for name in access.services]
    intervals = []
    if destination_set:
        for host in hosts.values():
            if str(host.address) not in destination_set:
                continue
            for port_key, host_service_name in host.ports.items():
                port_number, port_protocol = parse_port_key(port_key)
                if port_protocol != protocol:
                    continue
                if _service_matches(host_service_name, service_entries):
                    intervals.append((port_number, port_number))
    for service in service_entries:
        if not service.fixed_ports:
            continue
        for port_spec in service.ports:
            if port_spec.protocol == protocol:
                intervals.append((port_spec.first, port_spec.last))
    return _merge_intervals(intervals)


def _service_matches(host_service_name: str, services: List[PolicyService]) -> bool:
    """Match a host's service name to a canonical service or nmap alias."""
    normalized = host_service_name.strip().lower()
    for service in services:
        if normalized == service.name.strip().lower() or normalized in service.nmap_names:
            return True
    return False


def _merge_intervals(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    """Sort and merge overlapping or adjacent port intervals."""
    if not intervals:
        return []
    ordered = sorted(intervals)
    merged = []
    current_start, current_end = ordered[0]
    for start, end in ordered[1:]:
        if start <= current_end + 1:
            current_end = max(current_end, end)
        else:
            merged.append((current_start, current_end))
            current_start, current_end = start, end
    merged.append((current_start, current_end))
    return merged


def _format_intervals(intervals: List[Tuple[int, int]]) -> List[str]:
    """Format inclusive port intervals using low-high notation."""
    formatted = []
    for first, last in intervals:
        if first == last:
            formatted.append(str(first))
        else:
            formatted.append("{}-{}".format(first, last))
    return formatted


def _sorted_addresses(addresses: Iterable[ipaddress.IPv4Address]) -> Tuple[str, ...]:
    """Deduplicate and numerically sort IPv4 host addresses."""
    unique = {ipaddress.IPv4Address(address) for address in addresses}
    return tuple(str(address) for address in sorted(unique))


def _add_group(host_groups: Dict[str, HostGroup], group_members: Dict[str, Tuple[str, ...]],
               name: str, members: Tuple[str, ...], description: str) -> None:
    """Add a group, reusing an identical existing group if names collide."""
    existing = group_members.get(name)
    if existing is not None:
        if existing != members:
            raise ValueError("generated host group name {!r} collides with different members".format(name))
        return
    host_groups[name] = HostGroup(name, members, description)
    group_members[name] = members


def _unique_group_name(base_name: str, members: Tuple[str, ...],
                       group_members: Dict[str, Tuple[str, ...]]) -> str:
    """Resolve a rare group-name collision with a deterministic suffix."""
    if base_name not in group_members or group_members[base_name] == members:
        return base_name
    suffix = 2
    while True:
        suffix_text = "_{}".format(suffix)
        candidate = base_name[:31 - len(suffix_text)] + suffix_text
        if candidate not in group_members or group_members[candidate] == members:
            return candidate
        suffix += 1


def _canonical_roles(role_values: Tuple[str, ...], aliases: Dict[str, str]) -> Tuple[str, ...]:
    """Normalize access roles, preserving the built-in all pseudo-role."""
    resolved = []
    for value in role_values:
        normalized = value.strip().lower()
        canonical = "all" if normalized == "all" else aliases[normalized]
        if canonical not in resolved:
            resolved.append(canonical)
    return tuple(resolved)


def _checked_name(name: str) -> str:
    """Require a generated group name to fit the shared vendor constraints."""
    if GROUP_NAME_PATTERN.match(name) is None:
        raise ValueError("generated group name {!r} must match [a-z0-9_] and be at most 31 characters".format(name))
    return name
