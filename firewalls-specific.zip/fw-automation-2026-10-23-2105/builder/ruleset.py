"""Builder data models for renderer-independent firewall policy."""

from dataclasses import dataclass
from typing import Dict, Tuple, Union

from builder.topology import Firewall, IPNetwork


@dataclass(frozen=True)
class HostGroup:
    """A named set of sorted host addresses."""

    name: str
    members: Tuple[str, ...]
    description: str


@dataclass(frozen=True)
class PortGroup:
    """A protocol-specific set of ports and inclusive ranges."""

    name: str
    protocol: str
    ports: Tuple[str, ...]
    description: str


@dataclass(frozen=True)
class AllowRule:
    """One logical access rule for a single transport protocol."""

    name: str
    protocol: str
    source_group: str
    destination_group: str
    port_group: str
    description: str


@dataclass(frozen=True)
class Ruleset:
    """Complete vendor-independent policy input for one firewall."""

    stateful: bool
    firewall: Firewall
    lan_networks: Tuple[IPNetwork, ...]
    internal_networks: Tuple[IPNetwork, ...]
    host_groups: Tuple[HostGroup, ...]
    port_groups: Tuple[PortGroup, ...]
    allow_rules: Tuple[AllowRule, ...]
    icmp_allowed: bool
    block_ipv6: bool
    log_denied: bool
    log_only: bool
    options: Dict[str, object]

    @property
    def logical_rule_count(self) -> int:
        """Count allow rules plus the four common policy actions."""
        return len(self.allow_rules) + 4


def make_ruleset(firewall: Firewall, host_groups: Tuple[HostGroup, ...],
                 port_groups: Tuple[PortGroup, ...], allow_rules: Tuple[AllowRule, ...],
                 log_only: bool) -> Ruleset:
    """Create a Ruleset with the required fixed policy defaults."""
    return Ruleset(
        stateful=True,
        firewall=firewall,
        lan_networks=firewall.lan_networks,
        internal_networks=firewall.internal_networks,
        host_groups=host_groups,
        port_groups=port_groups,
        allow_rules=allow_rules,
        icmp_allowed=True,
        block_ipv6=True,
        log_denied=True,
        log_only=log_only,
        options=dict(firewall.options),
    )
