# Firewall automation

## Install

The scanner supports Python 3.6 and uses the preinstalled dependencies plus PyYAML:

```text
python -m pip install -r requirements-scan.txt
```

The firewall builder targets Python 3.13 or newer and uses:

```text
python -m pip install -r requirements-build.txt
```

## Commands

Run the scanner as root or Administrator, with nmap on `PATH`:

```text
python scan_network.py inputs/assumed.yaml [--policy policy.yaml] [--output-dir runs]
```

Build vendor configuration from a scan result and firewall inventory:

```text
python build_firewall.py runs/<run>/new.yaml inputs/firewall.yaml policy.yaml [--output-dir DIR] [--log-only]
```

## Input summary

- `assumed.yaml` maps hostnames to an IPv4 `ip`, a `generic` role or list of roles, and a `ports` mapping from `port/tcp` or `port/udp` to a service name. Other host keys are preserved.
- `firewall.yaml` maps firewall names to a supported `type` and interfaces. Each interface has a `generic_name`, IPv4 `ip_addr` and containing `ip_range`, and optional IPv6 network list `ipv6_ranges`.
- `policy.yaml` defines service ports and nmap names, role names and aliases, and ordered access rules.

## Workflow

`inputs/assumed.yaml` is scanned into a new timestamped `runs/<run>/` directory containing the original assumptions, raw TCP and UDP nmap XML, and `actual.yaml`, `new.yaml`, and `diff.yaml`. The builder consumes `new.yaml` together with `inputs/firewall.yaml` and `policy.yaml`; it writes generated configurations for the operator to apply manually.
