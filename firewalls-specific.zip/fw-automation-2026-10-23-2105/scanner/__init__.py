"""Network scanning stages."""
