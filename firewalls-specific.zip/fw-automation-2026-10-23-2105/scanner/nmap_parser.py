"""Parse nmap XML into host-indexed scan results."""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict

from common.models import ScanPort


def parse_nmap_xml(path: Path) -> Dict[str, Dict[str, ScanPort]]:
    """Return scan results indexed by IPv4 address and port key."""
    try:
        document = ET.parse(str(path))
    except (ET.ParseError, OSError) as error:
        raise ValueError("could not parse nmap XML {}: {}".format(path, error))
    results = {}
    for host_node in document.getroot().findall("host"):
        ipv4_addresses = [
            address_node.get("addr")
            for address_node in host_node.findall("address")
            if address_node.get("addrtype") == "ipv4" and address_node.get("addr")
        ]
        if not ipv4_addresses:
            continue
        host_ip = ipv4_addresses[0]
        host_ports = results.setdefault(host_ip, {})
        ports_node = host_node.find("ports")
        if ports_node is None:
            continue
        for port_node in ports_node.findall("port"):
            protocol = port_node.get("protocol")
            port_id = port_node.get("portid")
            if protocol not in ("tcp", "udp") or port_id is None:
                continue
            try:
                number = int(port_id)
            except ValueError:
                continue
            if number < 1 or number > 65535:
                continue
            state_node = port_node.find("state")
            if state_node is None:
                continue
            service_node = port_node.find("service")
            service_name = service_node.get("name", "") if service_node is not None else ""
            tunnel = service_node.get("tunnel", "") if service_node is not None else ""
            port_key = "{}/{}".format(number, protocol)
            scan_port = ScanPort(state_node.get("state", ""), service_name, tunnel)
            previous = host_ports.get(port_key)
            if previous is None or _state_priority(scan_port.state) > _state_priority(previous.state):
                host_ports[port_key] = scan_port
    return results


def _state_priority(state: str) -> int:
    """Prefer a confirmed open result if duplicate host entries appear."""
    if state == "open":
        return 3
    if state == "open|filtered":
        return 2
    return 1
