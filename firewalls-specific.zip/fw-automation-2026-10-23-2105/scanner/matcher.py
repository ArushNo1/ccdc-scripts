"""Resolve scanned services and merge observed ports with assumptions."""

from typing import Any, Dict, List, NamedTuple, Tuple

from common.models import Policy, PolicyService, ScanHost, ScanPort
from common.ports import parse_port_key, port_spec_contains, port_spec_width


class MatchResult(NamedTuple):
    """Per-run actual, merged, and difference YAML records."""

    actual: Dict[str, Any]
    new: Dict[str, Any]
    diff: Dict[str, Any]
    warnings: Tuple[str, ...]


def match_hosts(hosts: Dict[str, ScanHost], scan_results: Dict[str, Dict[str, ScanPort]],
                policy: Policy) -> MatchResult:
    """Resolve service names, move assumed ports, and build all output records."""
    actual_records = {}
    new_records = {}
    diff_records = {}
    warnings = []
    for host_name, host in hosts.items():
        scan_ports = scan_results.get(host.ip, {})
        resolved_open = {}
        unconfirmed = []
        for port_key, scan_port in scan_ports.items():
            if scan_port.state == "open":
                assumed_service = host.ports.get(port_key)
                resolved_name = _resolve_service(port_key, scan_port, assumed_service, policy)
                resolved_open[port_key] = resolved_name
            elif scan_port.state == "open|filtered" and port_key in host.ports and port_key.endswith("/udp"):
                unconfirmed.append(port_key)
        sorted_open = _sorted_port_mapping(resolved_open)
        actual_records[host_name] = _copy_host_data(host, sorted_open)
        if not resolved_open:
            new_ports = dict(host.ports)
            for port_key in unconfirmed:
                new_ports[port_key] = host.ports[port_key]
            new_records[host_name] = _copy_host_data(host, _sorted_port_mapping(new_ports))
            warning = "{} has zero confirmed open ports; assumed ports were retained".format(host_name)
            warnings.append(warning)
            diff_records[host_name] = {
                "confirmed": [],
                "moved": [],
                "new": [],
                "unknown": [],
                "missing": sorted(set(host.ports) - set(unconfirmed), key=parse_port_key),
                "unconfirmed": sorted(set(unconfirmed), key=parse_port_key),
            }
            continue

        new_ports, diff, host_warnings = _merge_host_ports(host, resolved_open, unconfirmed)
        new_records[host_name] = _copy_host_data(host, _sorted_port_mapping(new_ports))
        diff_records[host_name] = diff
        warnings.extend("{}: {}".format(host_name, warning) for warning in host_warnings)
    return MatchResult(actual_records, new_records, diff_records, tuple(warnings))


def _resolve_service(port_key: str, scan_port: ScanPort, assumed_service: Any,
                     policy: Policy) -> str:
    """Apply assumed-name, policy-name, then unknown precedence."""
    if isinstance(assumed_service, str):
        return assumed_service
    candidates = [scan_port.service_name.strip().lower()] if scan_port.service_name else []
    if scan_port.tunnel.strip().lower() == "ssl" and candidates:
        base_name = candidates[0]
        candidates = [base_name + "s", base_name + "ssl", base_name]
    for candidate in candidates:
        matches = [
            service for service in policy.services.values()
            if candidate in service.nmap_names
        ]
        if matches:
            port_number, protocol = parse_port_key(port_key)
            matching_port_services = [
                service for service in matches
                if any(port_spec_contains(port_spec, port_number, protocol) for port_spec in service.ports)
            ]
            if matching_port_services:
                matches = matching_port_services
            return min(matches, key=lambda service: (_service_port_width(service), service.name)).name
    return "unknown"


def _service_port_width(service: PolicyService) -> int:
    """Measure service specificity for deterministic shared-name selection."""
    if not service.ports:
        return 65536
    return min(port_spec_width(port_spec) for port_spec in service.ports)


def _merge_host_ports(host: ScanHost, open_ports: Dict[str, str],
                      unconfirmed: List[str]) -> Tuple[Dict[str, str], Dict[str, Any], List[str]]:
    """Classify confirmed, moved, new, unknown, missing, and unconfirmed ports."""
    assumed_ports = host.ports
    assumed_keys = set(assumed_ports)
    open_keys = set(open_ports)
    unconfirmed_set = set(unconfirmed)
    missing = set(assumed_keys - open_keys - unconfirmed_set)
    extra = set(open_keys - assumed_keys)
    result_ports = dict(open_ports)
    for port_key in unconfirmed_set:
        result_ports[port_key] = assumed_ports[port_key]
    moved = []
    warnings = []
    unmatched_assumed = set(missing)
    unmatched_extra = set(extra)

    for assumed_key in sorted(missing, key=parse_port_key):
        service_name = assumed_ports[assumed_key]
        _, assumed_protocol = parse_port_key(assumed_key)
        candidates = [
            candidate for candidate in unmatched_extra
            if parse_port_key(candidate)[1] == assumed_protocol
            and open_ports[candidate].casefold() == service_name.casefold()
        ]
        candidates.sort(key=parse_port_key)
        if not candidates:
            continue
        if len(candidates) > 1:
            warnings.append(
                "assumed port {} matches several discovered ports by service {}".format(
                    assumed_key, service_name
                )
            )
        destination_key = candidates[0]
        unmatched_assumed.remove(assumed_key)
        unmatched_extra.remove(destination_key)
        result_ports[destination_key] = service_name
        moved.append({
            "from": assumed_key,
            "to": destination_key,
            "service": service_name,
            "method": "service",
        })
        warnings.append("port {} moved to {} by service match".format(assumed_key, destination_key))

    for protocol in ("tcp", "udp"):
        remaining_assumed = sorted(
            [key for key in unmatched_assumed if parse_port_key(key)[1] == protocol],
            key=parse_port_key,
        )
        remaining_extra = sorted(
            [key for key in unmatched_extra if parse_port_key(key)[1] == protocol],
            key=parse_port_key,
        )
        if len(remaining_assumed) == 1 and len(remaining_extra) == 1:
            assumed_key = remaining_assumed[0]
            destination_key = remaining_extra[0]
            service_name = assumed_ports[assumed_key]
            unmatched_assumed.remove(assumed_key)
            unmatched_extra.remove(destination_key)
            result_ports[destination_key] = service_name
            moved.append({
                "from": assumed_key,
                "to": destination_key,
                "service": service_name,
                "method": "elimination",
            })
            warnings.append("port {} moved to {} by elimination".format(assumed_key, destination_key))

    confirmed = sorted(assumed_keys & open_keys, key=parse_port_key)
    missing_list = sorted(unmatched_assumed, key=parse_port_key)
    new_list = sorted(unmatched_extra, key=parse_port_key)
    unknown = sorted(
        [key for key in new_list if open_ports[key] == "unknown"],
        key=parse_port_key,
    )
    for port_key in unknown:
        warnings.append("port {} has unknown service and will not receive a firewall rule".format(port_key))
    diff = {
        "confirmed": confirmed,
        "moved": moved,
        "new": new_list,
        "unknown": unknown,
        "missing": missing_list,
        "unconfirmed": sorted(set(unconfirmed), key=parse_port_key),
    }
    for port_key in missing_list:
        result_ports.pop(port_key, None)
    return result_ports, diff, warnings


def _sorted_port_mapping(ports: Dict[str, str]) -> Dict[str, str]:
    """Return a port mapping ordered by numeric port and protocol."""
    return {key: ports[key] for key in sorted(ports, key=parse_port_key)}


def _copy_host_data(host: ScanHost, ports: Dict[str, str]) -> Dict[str, Any]:
    """Preserve all source fields while replacing the ports mapping."""
    result = dict(host.raw)
    result["ports"] = ports
    return result
