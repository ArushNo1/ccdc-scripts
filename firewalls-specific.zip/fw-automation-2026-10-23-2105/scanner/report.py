"""Console progress and closing scan summary."""

import logging
from pathlib import Path
from typing import List


class ScanReport:
    """Collect warnings and print the required final summary."""

    def __init__(self, logger: logging.Logger) -> None:
        """Create a report for one scan run."""
        self.logger = logger
        self.warnings = []  # type: List[str]

    def warning(self, message: str) -> None:
        """Log and retain an operator warning for the closing summary."""
        self.warnings.append(message)
        self.logger.warning(message)

    def host(self, host_name: str, port_count: int, unconfirmed_count: int) -> None:
        """Log one concise per-host progress line."""
        self.logger.info(
            "%s: %d confirmed open ports, %d unconfirmed UDP ports",
            host_name,
            port_count,
            unconfirmed_count,
        )

    def finish(self, yaml_paths: List[Path]) -> None:
        """Repeat all warnings and list the three generated YAML paths."""
        self.logger.info("Scan summary:")
        for warning in self.warnings:
            self.logger.warning(warning)
        for path in yaml_paths:
            self.logger.info("YAML output: %s", path)
