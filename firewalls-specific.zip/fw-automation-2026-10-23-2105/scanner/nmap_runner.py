"""Run the sequential TCP and bounded UDP nmap scans."""

import logging
import subprocess
import threading
import time
from pathlib import Path
from typing import Dict, List

from common.models import Policy, ScanHost

COMMON_UDP_PORTS = (
    53, 67, 69, 123, 137, 138, 161, 162, 389, 500,
    514, 520, 1194, 1701, 1812, 1813, 4500, 5060,
    5353, 51820,
)
TCP_SCAN_ARGUMENTS = (
    "-v", "-Pn", "-n", "-sS", "-sV", "--version-light", "-p-",
    "-T4", "--min-rate", "2000", "--max-retries", "2", "--open",
)
UDP_SCAN_ARGUMENTS = ("-v", "-Pn", "-n", "-sU", "-T4", "--max-retries", "1")


class NmapError(RuntimeError):
    """Raised when an nmap process cannot start or completes unsuccessfully."""


def build_udp_port_list(assumed_hosts: Dict[str, ScanHost], policy: Policy) -> List[int]:
    """Build the sorted, bounded UDP scan list from assumptions and policy."""
    ports = set(COMMON_UDP_PORTS)
    for host in assumed_hosts.values():
        for port_key in host.ports:
            number, protocol = port_key.split("/", 1)
            if protocol == "udp":
                ports.add(int(number))
    for service in policy.services.values():
        if service.fixed_ports:
            continue
        for port_spec in service.ports:
            if port_spec.protocol == "udp":
                ports.update(range(port_spec.first, port_spec.last + 1))
    return sorted(ports)


def run_scans(run_directory: Path, targets_path: Path, udp_ports: List[int],
              logger: logging.Logger) -> None:
    """Run TCP first and UDP second, retaining each raw XML file."""
    nmap_directory = run_directory / "nmap"
    nmap_directory.mkdir()
    tcp_xml = nmap_directory / "tcp.xml"
    udp_xml = nmap_directory / "udp.xml"
    _run_one_scan(
        "tcp",
        list(TCP_SCAN_ARGUMENTS) + ["-iL", str(targets_path), "-oX", str(tcp_xml)],
        logger,
    )
    _run_one_scan(
        "udp",
        list(UDP_SCAN_ARGUMENTS)
        + ["-p", ",".join(str(port) for port in udp_ports), "-iL", str(targets_path), "-oX", str(udp_xml)],
        logger,
    )


def _run_one_scan(scan_name: str, arguments: List[str], logger: logging.Logger) -> None:
    """Execute one scan while streaming stdout and draining stderr safely."""
    command = ["nmap"] + arguments
    logger.info("Starting %s scan", scan_name.upper())
    start_time = time.time()
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
        )
    except OSError as error:
        raise NmapError("could not start nmap: {}".format(error))

    stderr_lines = []

    def collect_stderr() -> None:
        if process.stderr is None:
            return
        for line in process.stderr:
            stderr_lines.append(line.rstrip("\r\n"))

    stderr_thread = threading.Thread(target=collect_stderr)
    stderr_thread.daemon = True
    stderr_thread.start()
    if process.stdout is not None:
        for line in process.stdout:
            clean_line = line.rstrip("\r\n")
            if "Discovered open port" in clean_line:
                logger.info("[%s] %s", scan_name, clean_line)
    return_code = process.wait()
    stderr_thread.join()
    elapsed = time.time() - start_time
    logger.info("%s scan elapsed time: %.1f seconds", scan_name.upper(), elapsed)
    if return_code != 0:
        for line in stderr_lines:
            logger.error("nmap %s stderr: %s", scan_name, line)
        if not stderr_lines:
            raise NmapError("nmap {} scan exited with status {} and no stderr".format(scan_name, return_code))
        raise NmapError("nmap {} scan exited with status {}".format(scan_name, return_code))
