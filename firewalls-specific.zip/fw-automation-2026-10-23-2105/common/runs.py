"""Create unique timestamped run directories without overwriting data."""

from datetime import datetime
from pathlib import Path


def create_run_directory(output_root: Path) -> Path:
    """Create a timestamped directory, adding a suffix on collisions."""
    output_root.mkdir(parents=True, exist_ok=True)
    base_name = datetime.now().strftime("%Y%m%d-%H%M%S")
    candidate = output_root / base_name
    suffix = 2
    while True:
        try:
            candidate.mkdir()
            return candidate
        except FileExistsError:
            candidate = output_root / "{}_{}".format(base_name, suffix)
            suffix += 1
