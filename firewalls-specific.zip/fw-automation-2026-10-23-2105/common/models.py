"""Typed data models shared by scanner stages."""

from typing import Any, Dict, NamedTuple, Tuple


class PortSpec(NamedTuple):
    """A single transport port or inclusive port range."""

    first: int
    last: int
    protocol: str


class PolicyService(NamedTuple):
    """A named service and the policy metadata used by scanning."""

    name: str
    ports: Tuple[PortSpec, ...]
    nmap_names: Tuple[str, ...]
    fixed_ports: bool


class PolicyAccess(NamedTuple):
    """An ordered policy access entry."""

    name: str
    from_roles: Tuple[str, ...]
    to_roles: Tuple[str, ...]
    services: Tuple[str, ...]


class Policy(NamedTuple):
    """Validated policy data needed by scanner and builder."""

    services: Dict[str, PolicyService]
    roles: Dict[str, Tuple[str, ...]]
    access: Tuple[PolicyAccess, ...]


class ScanPort(NamedTuple):
    """The scan state and service fingerprint for one port."""

    state: str
    service_name: str
    tunnel: str


class ScanHost(NamedTuple):
    """An assumed host and its preserved source mapping."""

    name: str
    ip: str
    generic: Any
    ports: Dict[str, str]
    raw: Dict[str, Any]
