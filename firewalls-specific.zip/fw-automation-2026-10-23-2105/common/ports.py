"""Strict port parsing and deterministic port ordering."""

import re
from typing import Tuple

from common.models import PortSpec


PORT_KEY_PATTERN = re.compile(r"^([0-9]+)/(?P<protocol>tcp|udp)$")
PORT_RANGE_PATTERN = re.compile(r"^([0-9]+)(?:-([0-9]+))?/(tcp|udp)$")
PROTOCOL_ORDER = {"tcp": 0, "udp": 1}


def parse_port_key(value: str) -> Tuple[int, str]:
    """Validate a concrete YAML port key and return its sort key."""
    match = PORT_KEY_PATTERN.match(value)
    if match is None:
        raise ValueError("port key must use '<port>/tcp' or '<port>/udp': {!r}".format(value))
    number = int(match.group(1))
    if number < 1 or number > 65535:
        raise ValueError("port number must be between 1 and 65535: {!r}".format(value))
    return number, match.group("protocol")


def parse_port_spec(value: str) -> PortSpec:
    """Validate a policy port or range."""
    match = PORT_RANGE_PATTERN.match(value)
    if match is None:
        raise ValueError("policy port must use '<port>/<proto>' or '<low-high>/<proto>': {!r}".format(value))
    first = int(match.group(1))
    last = int(match.group(2)) if match.group(2) is not None else first
    protocol = match.group(3)
    if first < 1 or last > 65535 or first > last:
        raise ValueError("invalid port range: {!r}".format(value))
    return PortSpec(first, last, protocol)


def port_sort_key(value: str) -> Tuple[int, int]:
    """Sort concrete ports by number, then TCP before UDP."""
    number, protocol = parse_port_key(value)
    return number, PROTOCOL_ORDER[protocol]


def port_spec_contains(spec: PortSpec, number: int, protocol: str) -> bool:
    """Return whether a policy port specification contains a scanned port."""
    return spec.protocol == protocol and spec.first <= number <= spec.last


def port_spec_width(spec: PortSpec) -> int:
    """Return the size of an inclusive range for deterministic tie-breaking."""
    return spec.last - spec.first + 1
