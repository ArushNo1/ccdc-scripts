"""Safe YAML input and deterministic output helpers."""

from pathlib import Path
from typing import Any, Dict

import yaml


class UniqueKeyLoader(yaml.SafeLoader):
    """Safe loader that rejects duplicate mapping keys."""


def _construct_unique_mapping(loader: UniqueKeyLoader, node: Any, deep: bool = False) -> Dict[Any, Any]:
    """Construct a mapping while preserving strict duplicate-key errors."""
    loader.flatten_mapping(node)
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            duplicate = key in mapping
        except TypeError as error:
            raise yaml.YAMLError("mapping key must be hashable") from error
        if duplicate:
            raise yaml.YAMLError("duplicate mapping key: {!r}".format(key))
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


def load_yaml(path: Path) -> Any:
    """Load YAML safely and reject duplicate keys."""
    try:
        with path.open("r", encoding="utf-8") as yaml_file:
            return yaml.load(yaml_file, Loader=UniqueKeyLoader)
    except yaml.YAMLError as error:
        raise ValueError("invalid YAML in {}: {}".format(path, error))


def dump_yaml(path: Path, data: Any) -> None:
    """Write deterministic block-style YAML without sorting mapping keys."""
    with path.open("w", encoding="utf-8", newline="\n") as yaml_file:
        yaml.safe_dump(
            data,
            yaml_file,
            sort_keys=False,
            default_flow_style=False,
            allow_unicode=True,
        )
