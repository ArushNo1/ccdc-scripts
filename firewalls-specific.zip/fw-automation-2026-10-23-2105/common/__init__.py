"""Shared, Python 3.6-compatible scanner data and helpers."""
