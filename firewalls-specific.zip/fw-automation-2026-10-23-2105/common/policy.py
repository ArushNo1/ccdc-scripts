"""Load and validate the policy data used during scanning."""

import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from common.models import Policy, PolicyAccess, PolicyService
from common.ports import parse_port_spec
from common.yaml_io import load_yaml


NAME_PATTERN = re.compile(r"^[a-z0-9_]{1,24}$")


def load_policy(path: Path) -> Policy:
    """Load policy services, roles, and access rules with strict validation."""
    raw = load_yaml(path)
    if not isinstance(raw, dict):
        raise ValueError("policy must be a YAML mapping")
    for required in ("defaults", "services", "roles", "access"):
        if required not in raw:
            raise ValueError("policy is missing required key {!r}".format(required))
    _validate_defaults(raw["defaults"])
    services = _parse_services(raw["services"])
    roles = _parse_roles(raw["roles"])
    access = _parse_access(raw["access"], services, roles)
    return Policy(services=services, roles=roles, access=access)


def _validate_defaults(raw: Any) -> None:
    """Validate the required, fixed policy defaults."""
    if not isinstance(raw, dict):
        raise ValueError("policy defaults must be a mapping")
    expected = {
        "stateful": True,
        "icmp": "allow",
        "log_denied": True,
        "ipv6": "deny",
    }
    for key, expected_value in expected.items():
        if raw.get(key) != expected_value or type(raw.get(key)) is not type(expected_value):
            raise ValueError("policy defaults.{0} must be {1!r}".format(key, expected_value))


def _parse_services(raw: Any) -> Dict[str, PolicyService]:
    """Validate service declarations and build name-indexed service data."""
    if not isinstance(raw, dict) or not raw:
        raise ValueError("policy services must be a non-empty mapping")
    services = {}
    for name, entry in raw.items():
        if not isinstance(name, str) or not name:
            raise ValueError("policy service names must be non-empty strings")
        if not isinstance(entry, dict):
            raise ValueError("policy service {!r} must be a mapping".format(name))
        port_values = entry.get("ports")
        if not isinstance(port_values, list) or not port_values:
            raise ValueError("policy service {!r} must have a non-empty ports list".format(name))
        try:
            ports = tuple(parse_port_spec(value) for value in port_values if isinstance(value, str))
        except ValueError as error:
            raise ValueError("policy service {!r}: {}".format(name, error))
        if len(ports) != len(port_values):
            raise ValueError("policy service {!r} ports must be strings".format(name))
        names_value = entry.get("nmap_names", [])
        if not isinstance(names_value, list) or any(not isinstance(item, str) or not item for item in names_value):
            raise ValueError("policy service {!r} nmap_names must be a list of non-empty strings".format(name))
        fixed_ports = entry.get("fixed_ports", False)
        if type(fixed_ports) is not bool:
            raise ValueError("policy service {!r} fixed_ports must be boolean".format(name))
        services[name] = PolicyService(
            name=name,
            ports=ports,
            nmap_names=tuple(item.strip().lower() for item in names_value),
            fixed_ports=fixed_ports,
        )
    return services


def _parse_roles(raw: Any) -> Dict[str, Tuple[str, ...]]:
    """Validate role names and aliases."""
    if not isinstance(raw, dict) or not raw:
        raise ValueError("policy roles must be a non-empty mapping")
    roles = {}
    for name, entry in raw.items():
        if not isinstance(name, str) or not name:
            raise ValueError("policy role names must be non-empty strings")
        if not isinstance(entry, dict):
            raise ValueError("policy role {!r} must be a mapping".format(name))
        aliases = entry.get("aliases", [])
        if not isinstance(aliases, list) or any(not isinstance(alias, str) or not alias.strip() for alias in aliases):
            raise ValueError("policy role {!r} aliases must be non-empty strings".format(name))
        roles[name] = tuple([name.strip().lower()] + [alias.strip().lower() for alias in aliases])
    return roles


def _parse_access(raw: Any, services: Dict[str, PolicyService],
                  roles: Dict[str, Tuple[str, ...]]) -> Tuple[PolicyAccess, ...]:
    """Validate ordered access entries."""
    if not isinstance(raw, list):
        raise ValueError("policy access must be a list")
    access = []
    seen_names = set()
    role_aliases = set()
    for role_name, aliases in roles.items():
        role_aliases.add(role_name.strip().lower())
        role_aliases.update(aliases)
    for index, entry in enumerate(raw):
        if not isinstance(entry, dict):
            raise ValueError("policy access entry {} must be a mapping".format(index))
        name = entry.get("name")
        if not isinstance(name, str) or NAME_PATTERN.match(name) is None:
            raise ValueError("policy access entry {} name must match [a-z0-9_], up to 24 characters".format(index))
        if name in seen_names:
            raise ValueError("duplicate policy access name {!r}".format(name))
        seen_names.add(name)
        from_roles = _string_list(entry.get("from"), "access {!r} from".format(name))
        to_roles = _string_list(entry.get("to"), "access {!r} to".format(name))
        service_names = _string_list(entry.get("services"), "access {!r} services".format(name))
        for role in from_roles + to_roles:
            if role != "all" and role.strip().lower() not in role_aliases:
                raise ValueError("policy access {!r} references unknown role {!r}".format(name, role))
        for service in service_names:
            if service not in services:
                raise ValueError("policy access {!r} references unknown service {!r}".format(name, service))
        access.append(PolicyAccess(name, tuple(from_roles), tuple(to_roles), tuple(service_names)))
    return tuple(access)


def _string_list(value: Any, description: str) -> List[str]:
    """Require a non-empty list of non-empty strings."""
    if not isinstance(value, list) or not value:
        raise ValueError("{} must be a non-empty list".format(description))
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError("{} must contain non-empty strings".format(description))
    return value


def role_alias_map(policy: Policy) -> Dict[str, str]:
    """Map normalized role names and aliases to canonical role names."""
    result = {}
    for role_name, aliases in policy.roles.items():
        for alias in aliases:
            result[alias] = role_name
    return result
